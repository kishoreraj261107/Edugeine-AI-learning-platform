import { Router } from 'express'
import { handleSummary } from '../controllers/summaryController.js'

const router = Router()

router.post('/', handleSummary)

export default router
