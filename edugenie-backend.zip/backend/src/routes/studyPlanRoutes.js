import { Router } from 'express'
import { handleStudyPlan } from '../controllers/studyPlanController.js'

const router = Router()

router.post('/', handleStudyPlan)

export default router
