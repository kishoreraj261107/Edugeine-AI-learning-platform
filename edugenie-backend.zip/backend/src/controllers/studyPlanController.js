import { createStudyPlan } from '../services/geminiService.js'

/**
 * POST /api/study-plan
 * Body: { subjects: string, hoursPerDay: number, days: number, examDate?: string, weakSubjects?: string }
 */
export async function handleStudyPlan(req, res, next) {
  try {
    const { subjects, hoursPerDay, days, examDate, weakSubjects } = req.body || {}

    if (!subjects || typeof subjects !== 'string' || !subjects.trim()) {
      return res.status(400).json({
        success: false,
        message: 'A non-empty "subjects" field is required.',
      })
    }

    const hours = Number(hoursPerDay)
    if (!Number.isFinite(hours) || hours <= 0 || hours > 24) {
      return res.status(400).json({
        success: false,
        message: '"hoursPerDay" must be a positive number (up to 24).',
      })
    }

    const numDays = Number(days)
    if (!Number.isInteger(numDays) || numDays < 1 || numDays > 60) {
      return res.status(400).json({
        success: false,
        message: '"days" must be an integer between 1 and 60.',
      })
    }

    const studyPlan = await createStudyPlan({
      subjects: subjects.trim(),
      hoursPerDay: hours,
      days: numDays,
      examDate: typeof examDate === 'string' ? examDate.trim() : '',
      weakSubjects: typeof weakSubjects === 'string' ? weakSubjects.trim() : '',
    })

    return res.status(200).json({ success: true, studyPlan })
  } catch (err) {
    return next(err)
  }
}
