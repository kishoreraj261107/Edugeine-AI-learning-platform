import { createQuiz } from '../services/geminiService.js'

const VALID_DIFFICULTIES = new Set(['easy', 'medium', 'hard'])

/**
 * POST /api/quiz
 * Body: { topic: string, numberOfQuestions: number, difficulty: 'easy'|'medium'|'hard' }
 */
export async function handleQuiz(req, res, next) {
  try {
    const { topic, numberOfQuestions, difficulty } = req.body || {}

    if (!topic || typeof topic !== 'string' || !topic.trim()) {
      return res.status(400).json({
        success: false,
        message: 'A non-empty "topic" field is required.',
      })
    }

    const count = Number(numberOfQuestions)
    if (!Number.isInteger(count) || count < 1 || count > 20) {
      return res.status(400).json({
        success: false,
        message: '"numberOfQuestions" must be an integer between 1 and 20.',
      })
    }

    const normalizedDifficulty = VALID_DIFFICULTIES.has(difficulty) ? difficulty : 'medium'

    const quiz = await createQuiz(topic.trim(), count, normalizedDifficulty)

    return res.status(200).json({ success: true, quiz })
  } catch (err) {
    return next(err)
  }
}
