import { summarize } from '../services/geminiService.js'

const VALID_LENGTHS = new Set(['short', 'medium', 'detailed'])

/**
 * POST /api/summary
 * Body: { text: string, length?: 'short'|'medium'|'detailed' }
 */
export async function handleSummary(req, res, next) {
  try {
    const { text, length } = req.body || {}

    if (!text || typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({
        success: false,
        message: 'A non-empty "text" field is required.',
      })
    }

    const normalizedLength = VALID_LENGTHS.has(length) ? length : 'medium'

    const summary = await summarize(text.trim(), normalizedLength)

    return res.status(200).json({ success: true, summary })
  } catch (err) {
    return next(err)
  }
}
