import { askTutor } from '../services/geminiService.js'

/**
 * POST /api/chat
 * Body: { question: string, context?: string }
 */
export async function handleChat(req, res, next) {
  try {
    const { question, context } = req.body || {}

    if (!question || typeof question !== 'string' || !question.trim()) {
      return res.status(400).json({
        success: false,
        message: 'A non-empty "question" field is required.',
      })
    }

    const answer = await askTutor(question.trim(), typeof context === 'string' ? context : '')

    return res.status(200).json({ success: true, answer })
  } catch (err) {
    return next(err)
  }
}
