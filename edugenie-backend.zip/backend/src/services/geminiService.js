import { GoogleGenAI } from '@google/genai'

// ---------------------------------------------------------------------------
// Client setup
// ---------------------------------------------------------------------------
// The Gemini API key never leaves the server. It is read once from the
// environment and used to construct a single shared client instance.

let client = null

function getClient() {
  if (!process.env.GEMINI_API_KEY) {
    throw new Error(
      'GEMINI_API_KEY is not configured on the server. Set it in your .env file.'
    )
  }
  if (!client) {
    client = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY })
  }
  return client
}

const MODEL = 'gemini-2.0-flash'

/**
 * Low-level helper: sends a prompt to Gemini and returns the raw text response.
 * @param {string} prompt
 * @param {{ json?: boolean }} [options]
 * @returns {Promise<string>}
 */
async function generateContent(prompt, options = {}) {
  const ai = getClient()

  let response
  try {
    response = await ai.models.generateContent({
      model: MODEL,
      contents: prompt,
      config: options.json
        ? { responseMimeType: 'application/json' }
        : undefined,
    })
  } catch (err) {
    const reason = err?.message || 'Unknown error contacting Gemini.'
    throw new Error(`Gemini request failed: ${reason}`)
  }

  const text = response?.text
  if (!text || typeof text !== 'string' || !text.trim()) {
    throw new Error('Gemini returned an empty response.')
  }

  return text.trim()
}

/**
 * Strips ```json / ``` fences that Gemini sometimes wraps JSON in, then
 * parses the result. Throws a descriptive error on malformed JSON so
 * controllers can turn it into a clean 500 response.
 * @param {string} rawText
 * @returns {any}
 */
function parseJSONResponse(rawText) {
  let cleaned = rawText.trim()

  // Remove leading ```json or ``` and trailing ``` fences, if present.
  cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/```\s*$/i, '')

  // In case there is any stray text before/after the JSON object, extract
  // the first balanced {...} or [...] block as a best-effort fallback.
  const firstBrace = cleaned.search(/[{[]/)
  if (firstBrace > 0) {
    cleaned = cleaned.slice(firstBrace)
  }

  try {
    return JSON.parse(cleaned)
  } catch (err) {
    throw new Error('Gemini returned a response that could not be parsed as JSON.')
  }
}

// ---------------------------------------------------------------------------
// Feature 1 — AI Tutor Chat
// ---------------------------------------------------------------------------

/**
 * @param {string} question
 * @param {string} [context]
 * @returns {Promise<string>} answer
 */
export async function askTutor(question, context = '') {
  const prompt = `You are EduGenie, a friendly and knowledgeable AI tutor for college students.

Your teaching style:
- Explain concepts simply and clearly, in plain language.
- Break difficult topics into small, logical steps.
- Give concrete examples to reinforce understanding.
- For programming questions, include a short, correct, runnable code example.
- Be helpful and encouraging, but do not over-explain — get to the point and respect the student's time.
- Do not use markdown headings; short paragraphs, numbered steps, or bullet points are fine.

${context ? `Recent conversation context (for continuity only, do not repeat it back):\n${context}\n` : ''}
Student's question:
${question}

Answer as EduGenie:`

  return generateContent(prompt)
}

// ---------------------------------------------------------------------------
// Feature 2 — Summarizer
// ---------------------------------------------------------------------------

const LENGTH_GUIDANCE = {
  short: 'Keep it very concise — around 3 to 5 bullet points or a short paragraph covering only the most essential points.',
  medium: 'Provide a moderate-length summary — a few short paragraphs or a mix of paragraphs and bullet points covering the main ideas and key details.',
  detailed: 'Provide a thorough, detailed summary that preserves structure, covers all major points, and includes supporting details, definitions, and formulas.',
}

/**
 * @param {string} text
 * @param {'short'|'medium'|'detailed'} length
 * @returns {Promise<string>} summary
 */
export async function summarize(text, length = 'medium') {
  const guidance = LENGTH_GUIDANCE[length] || LENGTH_GUIDANCE.medium

  const prompt = `You are EduGenie's summarizer. Summarize the study material below for a college student.

Rules:
- Preserve all important facts, figures, definitions, and formulas exactly as given — do not invent or alter information.
- Use clear headings and bullet points where helpful for readability.
- ${guidance}
- Do not add information that is not present in the source text.
- Respond with plain text / markdown-style formatting only (no code fences).

Text to summarize:
"""
${text}
"""

Summary:`

  return generateContent(prompt)
}

// ---------------------------------------------------------------------------
// Feature 3 — Quiz Generator
// ---------------------------------------------------------------------------

/**
 * @param {string} topic
 * @param {number} numberOfQuestions
 * @param {'easy'|'medium'|'hard'} difficulty
 * @returns {Promise<object>} quiz object
 */
export async function createQuiz(topic, numberOfQuestions, difficulty) {
  const prompt = `You are EduGenie's quiz generator. Create a multiple-choice quiz for a college student.

Topic: ${topic}
Number of questions: ${numberOfQuestions}
Difficulty: ${difficulty}

Requirements:
- Return ONLY valid JSON, with no markdown code fences and no commentary before or after it.
- The JSON must exactly match this shape:
{
  "title": "string, a short quiz title",
  "topic": "string, the topic",
  "difficulty": "easy|medium|hard",
  "questions": [
    {
      "question": "string",
      "options": ["string", "string", "string", "string"],
      "answer": 0,
      "explanation": "string, a short explanation of the correct answer"
    }
  ]
}
- "options" must contain EXACTLY four items per question.
- "answer" must be a zero-based index (0, 1, 2, or 3) pointing to the correct option in "options".
- Generate exactly ${numberOfQuestions} questions.
- Questions must match the "${difficulty}" difficulty level and be relevant to "${topic}".
- Do not repeat the same question twice.`

  const rawText = await generateContent(prompt, { json: true })
  const parsed = parseJSONResponse(rawText)

  return validateQuiz(parsed, { topic, numberOfQuestions, difficulty })
}

/**
 * Validates and normalizes a quiz object returned by Gemini, ensuring the
 * response is safe to send to the frontend even if the model slightly
 * deviated from the requested shape.
 */
function validateQuiz(quiz, { topic, numberOfQuestions, difficulty }) {
  if (!quiz || typeof quiz !== 'object' || !Array.isArray(quiz.questions)) {
    throw new Error('Gemini returned a quiz in an unexpected format.')
  }

  const questions = quiz.questions
    .filter((q) => q && typeof q.question === 'string' && Array.isArray(q.options))
    .map((q) => {
      const options = q.options.slice(0, 4).map((opt) => String(opt))
      while (options.length < 4) options.push('N/A')

      let answer = Number.isInteger(q.answer) ? q.answer : parseInt(q.answer, 10)
      if (!Number.isInteger(answer) || answer < 0 || answer > 3) answer = 0

      return {
        question: String(q.question),
        options,
        answer,
        explanation: typeof q.explanation === 'string' ? q.explanation : '',
      }
    })

  if (questions.length === 0) {
    throw new Error('Gemini did not return any valid quiz questions.')
  }

  return {
    title: typeof quiz.title === 'string' && quiz.title.trim() ? quiz.title : `${topic} Quiz`,
    topic: typeof quiz.topic === 'string' && quiz.topic.trim() ? quiz.topic : topic,
    difficulty: typeof quiz.difficulty === 'string' && quiz.difficulty.trim() ? quiz.difficulty : difficulty,
    questions: questions.slice(0, numberOfQuestions),
  }
}

// ---------------------------------------------------------------------------
// Feature 4 — Study Plan
// ---------------------------------------------------------------------------

/**
 * @param {{ subjects: string, hoursPerDay: number, days: number, examDate: string, weakSubjects: string }} params
 * @returns {Promise<object>} studyPlan object
 */
export async function createStudyPlan({ subjects, hoursPerDay, days, examDate, weakSubjects }) {
  const prompt = `You are EduGenie's study planner. Build a realistic, personalized study plan for a college student.

Subjects: ${subjects}
Hours available per day: ${hoursPerDay}
Number of days until the plan ends: ${days}
Exam date: ${examDate || 'not specified'}
Weak subjects (need extra focus): ${weakSubjects || 'none specified'}

Requirements:
- Return ONLY valid JSON, with no markdown code fences and no commentary before or after it.
- The JSON must exactly match this shape:
{
  "title": "string, a short plan title",
  "overview": "string, a brief 1-3 sentence overview of the strategy",
  "dailyPlan": [
    {
      "day": 1,
      "focus": "string, what this day focuses on",
      "sessions": [
        { "subject": "string", "duration": "string, e.g. '45 min'", "activity": "string, what to actually do" }
      ]
    }
  ],
  "tips": ["string", "string"]
}
- Create exactly ${days} entries in "dailyPlan", numbered 1 through ${days}.
- The total duration of sessions on each day must respect the ${hoursPerDay} hour(s) per day limit — do not overload any single day.
- Give more session time and frequency to the weak subjects listed above.
- Include dedicated revision sessions, especially in the days closer to the exam date.
- Include at least one practice/test session (practice problems, past papers, or self-quizzing) before the exam date.
- Make the schedule realistic and varied — avoid scheduling the same single subject for the entire day, every day.
- "tips" should contain 3 to 6 short, practical study tips relevant to this plan.`

  const rawText = await generateContent(prompt, { json: true })
  const parsed = parseJSONResponse(rawText)

  return validateStudyPlan(parsed, { days })
}

/**
 * Validates and normalizes a study plan object returned by Gemini.
 */
function validateStudyPlan(plan, { days }) {
  if (!plan || typeof plan !== 'object' || !Array.isArray(plan.dailyPlan)) {
    throw new Error('Gemini returned a study plan in an unexpected format.')
  }

  const dailyPlan = plan.dailyPlan
    .filter((d) => d && typeof d === 'object')
    .map((d, idx) => {
      const sessions = Array.isArray(d.sessions)
        ? d.sessions
            .filter((s) => s && typeof s === 'object')
            .map((s) => ({
              subject: typeof s.subject === 'string' ? s.subject : 'Study session',
              duration: typeof s.duration === 'string' ? s.duration : '',
              activity: typeof s.activity === 'string' ? s.activity : '',
            }))
        : []

      return {
        day: Number.isInteger(d.day) ? d.day : idx + 1,
        focus: typeof d.focus === 'string' ? d.focus : '',
        sessions,
      }
    })

  if (dailyPlan.length === 0) {
    throw new Error('Gemini did not return any valid study plan days.')
  }

  return {
    title: typeof plan.title === 'string' && plan.title.trim() ? plan.title : 'Your Study Plan',
    overview: typeof plan.overview === 'string' ? plan.overview : '',
    dailyPlan: dailyPlan.slice(0, days || dailyPlan.length),
    tips: Array.isArray(plan.tips) ? plan.tips.filter((t) => typeof t === 'string') : [],
  }
}
