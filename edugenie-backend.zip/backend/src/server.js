import 'dotenv/config'
import express from 'express'
import cors from 'cors'

import chatRoutes from './routes/chatRoutes.js'
import summaryRoutes from './routes/summaryRoutes.js'
import quizRoutes from './routes/quizRoutes.js'
import studyPlanRoutes from './routes/studyPlanRoutes.js'

const app = express()
const PORT = process.env.PORT || 5000
const FRONTEND_URL = process.env.FRONTEND_URL || 'http://localhost:5173'

// ---------------------------------------------------------------------------
// Middleware
// ---------------------------------------------------------------------------
app.use(
  cors({
    origin: FRONTEND_URL,
  })
)
app.use(express.json({ limit: '2mb' }))

// ---------------------------------------------------------------------------
// Health check
// ---------------------------------------------------------------------------
app.get('/', (req, res) => {
  res.status(200).json({
    success: true,
    message: 'EduGenie API is running',
  })
})

// ---------------------------------------------------------------------------
// Feature routes
// ---------------------------------------------------------------------------
app.use('/api/chat', chatRoutes)
app.use('/api/summary', summaryRoutes)
app.use('/api/quiz', quizRoutes)
app.use('/api/study-plan', studyPlanRoutes)

// ---------------------------------------------------------------------------
// 404 handler — must come after all routes
// ---------------------------------------------------------------------------
app.use((req, res) => {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.method} ${req.originalUrl}`,
  })
})

// ---------------------------------------------------------------------------
// Global error handler — must be the last middleware
// ---------------------------------------------------------------------------
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  console.error('[EduGenie API Error]', err.message)

  const statusCode = err.statusCode && Number.isInteger(err.statusCode) ? err.statusCode : 500

  res.status(statusCode).json({
    success: false,
    message: statusCode === 500 ? 'Something went wrong while processing your request.' : err.message,
  })
})

app.listen(PORT, () => {
  console.log(`EduGenie API is running on http://localhost:${PORT}`)
})
