/**
 * Reusable loading indicator.
 * @param {{ label?: string, size?: 'inline'|'panel' }} props
 */
function Loading({ label = 'Loading...', size = 'inline' }) {
  if (size === 'panel') {
    return (
      <div className="loading-panel">
        <div className="spinner spinner-lg" />
        <span>{label}</span>
      </div>
    )
  }

  return (
    <div className="loading-inline">
      <div className="spinner" />
      <span>{label}</span>
    </div>
  )
}

export default Loading
