import { useEffect, useRef, useState } from 'react'
import { Bot, Send, Trash2, Sparkles } from 'lucide-react'
import MessageBubble from './MessageBubble.jsx'
import { askTutor } from '../services/api.js'

const SUGGESTED_QUESTIONS = [
  'Explain photosynthesis in simple terms',
  'What is the difference between TCP and UDP?',
  'Help me understand Newton\'s second law',
  'Give me tips to manage exam stress',
]

function ChatBox() {
  const [messages, setMessages] = useState([])
  const [input, setInput] = useState('')
  const [isSending, setIsSending] = useState(false)
  const messagesEndRef = useRef(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages, isSending])

  async function sendMessage(text) {
    const question = text.trim()
    if (!question || isSending) return

    const userMessage = { role: 'user', content: question }
    setMessages((prev) => [...prev, userMessage])
    setInput('')
    setIsSending(true)

    try {
      const conversationContext = messages
        .slice(-6)
        .map((m) => `${m.role}: ${m.content}`)
        .join('\n')

      const answer = await askTutor(question, conversationContext)
      setMessages((prev) => [...prev, { role: 'assistant', content: answer }])
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: err.message, isError: true },
      ])
    } finally {
      setIsSending(false)
    }
  }

  function handleSubmit(e) {
    e.preventDefault()
    sendMessage(input)
  }

  function handleKeyDown(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      sendMessage(input)
    }
  }

  function clearChat() {
    setMessages([])
  }

  return (
    <div className="card chat-box">
      <div className="chat-toolbar">
        <div className="chat-toolbar-title">
          <Bot size={20} color="var(--navy)" />
          AI Tutor
        </div>
        <button className="btn btn-ghost btn-sm" onClick={clearChat} disabled={messages.length === 0}>
          <Trash2 size={15} /> Clear chat
        </button>
      </div>

      <div className="chat-messages">
        {messages.length === 0 && (
          <div className="chat-empty">
            <Sparkles size={28} color="var(--soft-pink)" />
            <h3>Ask me anything about your coursework</h3>
            <p>I can explain concepts, solve problems, and help you study smarter.</p>
            <div className="suggested-questions">
              {SUGGESTED_QUESTIONS.map((q) => (
                <button key={q} className="suggested-chip" onClick={() => sendMessage(q)}>
                  {q}
                </button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, idx) => (
          <MessageBubble key={idx} role={m.role} content={m.content} isError={m.isError} />
        ))}

        {isSending && (
          <div className="message-row assistant">
            <div className="message-avatar">
              <Bot size={16} />
            </div>
            <div className="message-bubble">
              <div className="typing-dots">
                <span /> <span /> <span />
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <form className="chat-input-area" onSubmit={handleSubmit}>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder="Type your question... (Enter to send, Shift+Enter for new line)"
          aria-label="Chat message"
          disabled={isSending}
        />
        <button type="submit" className="btn btn-accent" disabled={isSending || !input.trim()}>
          <Send size={16} />
          Send
        </button>
      </form>
    </div>
  )
}

export default ChatBox
