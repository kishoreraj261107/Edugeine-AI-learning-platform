import { useState } from 'react'
import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard,
  MessageCircle,
  FileText,
  ListChecks,
  CalendarClock,
  UserCircle,
  Sparkles,
  Menu,
  X,
} from 'lucide-react'

const navItems = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/ai-tutor', label: 'AI Tutor', icon: MessageCircle },
  { to: '/summarizer', label: 'Summarizer', icon: FileText },
  { to: '/quiz', label: 'Quiz Generator', icon: ListChecks },
  { to: '/study-plan', label: 'Study Plan', icon: CalendarClock },
  { to: '/profile', label: 'Profile', icon: UserCircle },
]

function Navbar() {
  const [open, setOpen] = useState(false)

  return (
    <>
      <header className="navbar">
        <div className="navbar-brand">
          <div className="navbar-brand-mark">
            <Sparkles size={16} color="#ffffff" />
          </div>
          EduGenie
        </div>
        <button
          className="navbar-toggle"
          onClick={() => setOpen((prev) => !prev)}
          aria-label={open ? 'Close menu' : 'Open menu'}
          aria-expanded={open}
        >
          {open ? <X size={20} /> : <Menu size={20} />}
        </button>
      </header>

      {open && (
        <div className="navbar-drawer">
          <nav className="sidebar-nav">
            {navItems.map(({ to, label, icon: Icon, end }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                onClick={() => setOpen(false)}
                className={({ isActive }) => `sidebar-link${isActive ? ' active' : ''}`}
              >
                <Icon size={19} />
                <span>{label}</span>
              </NavLink>
            ))}
          </nav>
        </div>
      )}
    </>
  )
}

export default Navbar
