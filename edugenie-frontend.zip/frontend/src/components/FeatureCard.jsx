import { useNavigate } from 'react-router-dom'
import { ArrowRight } from 'lucide-react'

/**
 * Clickable feature card used on the Dashboard.
 * @param {{ icon: React.ComponentType, title: string, description: string, to: string }} props
 */
function FeatureCard({ icon: Icon, title, description, to }) {
  const navigate = useNavigate()

  return (
    <div
      className="card feature-card"
      role="button"
      tabIndex={0}
      onClick={() => navigate(to)}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') navigate(to)
      }}
    >
      <div className="feature-card-icon">
        <Icon size={22} />
      </div>
      <div>
        <h3>{title}</h3>
        <p>{description}</p>
      </div>
      <span style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: '0.82rem', fontWeight: 600, color: 'var(--navy)' }}>
        Open <ArrowRight size={14} />
      </span>
    </div>
  )
}

export default FeatureCard
