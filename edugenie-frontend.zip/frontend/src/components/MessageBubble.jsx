import { Bot, User, AlertTriangle } from 'lucide-react'

/**
 * Single chat message bubble.
 * @param {{ role: 'user'|'assistant', content: string, isError?: boolean }} props
 */
function MessageBubble({ role, content, isError = false }) {
  const isUser = role === 'user'

  return (
    <div className={`message-row ${isUser ? 'user' : 'assistant'}`}>
      <div className="message-avatar">
        {isUser ? <User size={16} /> : <Bot size={16} />}
      </div>
      <div className={`message-bubble${isError ? ' error' : ''}`}>
        {isError && <AlertTriangle size={14} style={{ marginRight: 6, verticalAlign: '-2px' }} />}
        {content}
      </div>
    </div>
  )
}

export default MessageBubble
