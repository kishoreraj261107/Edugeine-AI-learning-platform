import { Check, X, Lightbulb } from 'lucide-react'

const OPTION_LETTERS = ['A', 'B', 'C', 'D', 'E', 'F']

/**
 * Displays a single quiz question with selectable options.
 * When `submitted` is true, shows correct/incorrect states and explanation.
 *
 * @param {{
 *   question: { question: string, options: string[], answer: number, explanation: string },
 *   selectedIndex: number|null,
 *   submitted: boolean,
 *   onSelect: (index: number) => void,
 * }} props
 */
function QuizCard({ question, selectedIndex, submitted, onSelect }) {
  return (
    <div className="card quiz-card">
      <h3 className="quiz-question">{question.question}</h3>

      <div className="quiz-options">
        {question.options.map((option, idx) => {
          let stateClass = ''
          if (submitted) {
            if (idx === question.answer) stateClass = 'correct'
            else if (idx === selectedIndex) stateClass = 'incorrect'
          } else if (idx === selectedIndex) {
            stateClass = 'selected'
          }

          return (
            <button
              key={idx}
              type="button"
              className={`quiz-option ${stateClass}`}
              onClick={() => !submitted && onSelect(idx)}
              disabled={submitted}
            >
              <span className="quiz-option-marker">
                {submitted && idx === question.answer ? (
                  <Check size={14} />
                ) : submitted && idx === selectedIndex ? (
                  <X size={14} />
                ) : (
                  OPTION_LETTERS[idx] || idx + 1
                )}
              </span>
              {option}
            </button>
          )
        })}
      </div>

      {submitted && question.explanation && (
        <div className="quiz-explanation">
          <strong style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 6, color: 'var(--text-primary)' }}>
            <Lightbulb size={14} /> Explanation
          </strong>
          {question.explanation}
        </div>
      )}
    </div>
  )
}

export default QuizCard
