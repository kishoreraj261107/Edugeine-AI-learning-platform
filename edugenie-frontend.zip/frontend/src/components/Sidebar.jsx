import { NavLink } from 'react-router-dom'
import {
  LayoutDashboard,
  MessageCircle,
  FileText,
  ListChecks,
  CalendarClock,
  UserCircle,
  Sparkles,
} from 'lucide-react'

const navItems = [
  { to: '/', label: 'Dashboard', icon: LayoutDashboard, end: true },
  { to: '/ai-tutor', label: 'AI Tutor', icon: MessageCircle },
  { to: '/summarizer', label: 'Summarizer', icon: FileText },
  { to: '/quiz', label: 'Quiz Generator', icon: ListChecks },
  { to: '/study-plan', label: 'Study Plan', icon: CalendarClock },
  { to: '/profile', label: 'Profile', icon: UserCircle },
]

function Sidebar() {
  return (
    <aside className="sidebar" aria-label="Main navigation">
      <div className="sidebar-brand">
        <div className="sidebar-brand-mark">
          <Sparkles size={18} color="#ffffff" />
        </div>
        <span className="sidebar-brand-name">EduGenie</span>
      </div>

      <nav className="sidebar-nav">
        {navItems.map(({ to, label, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) => `sidebar-link${isActive ? ' active' : ''}`}
          >
            <Icon size={19} />
            <span>{label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="sidebar-footer">EduGenie v1.0 · Powered by Gemini</div>
    </aside>
  )
}

export default Sidebar
