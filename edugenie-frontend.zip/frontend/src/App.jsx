import { Routes, Route } from 'react-router-dom'
import Sidebar from './components/Sidebar.jsx'
import Navbar from './components/Navbar.jsx'
import Dashboard from './pages/Dashboard.jsx'
import AIChat from './pages/AIChat.jsx'
import Summarizer from './pages/Summarizer.jsx'
import Quiz from './pages/Quiz.jsx'
import StudyPlan from './pages/StudyPlan.jsx'
import Profile from './pages/Profile.jsx'

function App() {
  return (
    <div className="app-shell">
      <Sidebar />
      <div className="app-main">
        <Navbar />
        <main className="app-content">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/ai-tutor" element={<AIChat />} />
            <Route path="/summarizer" element={<Summarizer />} />
            <Route path="/quiz" element={<Quiz />} />
            <Route path="/study-plan" element={<StudyPlan />} />
            <Route path="/profile" element={<Profile />} />
          </Routes>
        </main>
      </div>
    </div>
  )
}

export default App
