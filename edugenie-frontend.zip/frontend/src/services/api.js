// Central API service for EduGenie.
// All backend requests go through this module so components never
// duplicate fetch logic or hardcode the base URL.

const BASE_URL = 'http://localhost:5000/api'

/**
 * Generic POST helper with consistent error handling.
 * Throws an Error with a user-friendly message on failure.
 */
async function postJSON(path, body) {
  let response
  try {
    response = await fetch(`${BASE_URL}${path}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    })
  } catch (networkError) {
    throw new Error(
      'Could not reach the EduGenie server. Make sure the backend is running on http://localhost:5000.'
    )
  }

  let data
  try {
    data = await response.json()
  } catch (parseError) {
    throw new Error('The server returned an unexpected response.')
  }

  if (!response.ok || data.success === false) {
    throw new Error(data.message || data.error || 'Something went wrong. Please try again.')
  }

  return data
}

/**
 * AI Tutor chat.
 * @param {string} question
 * @param {string} [context]
 * @returns {Promise<string>} answer text
 */
export async function askTutor(question, context = '') {
  const data = await postJSON('/chat', { question, context })
  return data.answer
}

/**
 * Summarize a block of text.
 * @param {string} text
 * @param {'short'|'medium'|'detailed'} length
 * @returns {Promise<string>} summary text
 */
export async function summarizeText(text, length = 'medium') {
  const data = await postJSON('/summary', { text, length })
  return data.summary
}

/**
 * Generate a quiz.
 * @param {string} topic
 * @param {number} numberOfQuestions
 * @param {'easy'|'medium'|'hard'} difficulty
 * @returns {Promise<object>} quiz object
 */
export async function generateQuiz(topic, numberOfQuestions, difficulty) {
  const data = await postJSON('/quiz', {
    topic,
    numberOfQuestions,
    difficulty,
  })
  return data.quiz
}

/**
 * Generate a study plan.
 * @param {object} params
 * @param {string} params.subjects
 * @param {number} params.hoursPerDay
 * @param {number} params.days
 * @param {string} params.examDate
 * @param {string} params.weakSubjects
 * @returns {Promise<object>} studyPlan object
 */
export async function generateStudyPlan({ subjects, hoursPerDay, days, examDate, weakSubjects }) {
  const data = await postJSON('/study-plan', {
    subjects,
    hoursPerDay,
    days,
    examDate,
    weakSubjects,
  })
  return data.studyPlan
}
