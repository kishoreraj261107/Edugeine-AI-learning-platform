import { useState } from 'react'
import { CalendarClock, AlertTriangle, Clock, Lightbulb, RotateCcw } from 'lucide-react'
import Loading from '../components/Loading.jsx'
import { generateStudyPlan } from '../services/api.js'

function StudyPlan() {
  const [subjects, setSubjects] = useState('')
  const [hoursPerDay, setHoursPerDay] = useState(3)
  const [days, setDays] = useState(7)
  const [examDate, setExamDate] = useState('')
  const [weakSubjects, setWeakSubjects] = useState('')

  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [plan, setPlan] = useState(null)

  async function handleSubmit(e) {
    e.preventDefault()
    if (!subjects.trim()) {
      setError('Please list at least one subject.')
      return
    }
    setError('')
    setIsLoading(true)

    try {
      const result = await generateStudyPlan({
        subjects: subjects.trim(),
        hoursPerDay: Number(hoursPerDay),
        days: Number(days),
        examDate,
        weakSubjects: weakSubjects.trim(),
      })
      setPlan(result)
    } catch (err) {
      setError(err.message)
    } finally {
      setIsLoading(false)
    }
  }

  function resetForm() {
    setPlan(null)
    setSubjects('')
    setHoursPerDay(3)
    setDays(7)
    setExamDate('')
    setWeakSubjects('')
  }

  return (
    <div>
      <div className="page-header">
        <h1>Study Plan</h1>
        <p>Tell EduGenie about your exam and get a personalized day-by-day study schedule.</p>
      </div>

      {error && (
        <div className="error-banner">
          <AlertTriangle size={16} />
          {error}
        </div>
      )}

      {!plan && (
        <form className="card plan-form-card" onSubmit={handleSubmit}>
          <div className="field">
            <label htmlFor="subjects">Subjects</label>
            <input
              id="subjects"
              type="text"
              value={subjects}
              onChange={(e) => setSubjects(e.target.value)}
              placeholder="e.g. Calculus, Organic Chemistry, Data Structures"
            />
            <span className="field-hint">Separate multiple subjects with commas.</span>
          </div>

          <div className="form-row">
            <div className="field">
              <label htmlFor="hoursPerDay">Hours per day</label>
              <input
                id="hoursPerDay"
                type="number"
                min="1"
                max="16"
                value={hoursPerDay}
                onChange={(e) => setHoursPerDay(e.target.value)}
              />
            </div>
            <div className="field">
              <label htmlFor="days">Number of days</label>
              <input
                id="days"
                type="number"
                min="1"
                max="60"
                value={days}
                onChange={(e) => setDays(e.target.value)}
              />
            </div>
          </div>

          <div className="field">
            <label htmlFor="examDate">Exam date</label>
            <input
              id="examDate"
              type="date"
              value={examDate}
              onChange={(e) => setExamDate(e.target.value)}
            />
          </div>

          <div className="field">
            <label htmlFor="weakSubjects">Weak subjects</label>
            <textarea
              id="weakSubjects"
              value={weakSubjects}
              onChange={(e) => setWeakSubjects(e.target.value)}
              placeholder="Which topics or subjects do you struggle with most?"
              style={{ minHeight: 90 }}
            />
          </div>

          <button className="btn btn-accent btn-block" type="submit" disabled={isLoading}>
            <CalendarClock size={16} />
            {isLoading ? 'Building your plan...' : 'Generate Study Plan'}
          </button>

          {isLoading && <Loading label="Gemini is building your study plan..." />}
        </form>
      )}

      {plan && (
        <div>
          <div className="card" style={{ padding: 24, marginBottom: 24 }}>
            <div className="panel-title">
              <CalendarClock size={18} color="var(--navy)" />
              {plan.title || 'Your Study Plan'}
            </div>
            <p>{plan.overview}</p>
            <button className="btn btn-outline btn-sm" style={{ marginTop: 16 }} onClick={resetForm}>
              <RotateCcw size={14} /> Create a new plan
            </button>
          </div>

          <h2 className="section-title">Daily schedule</h2>
          {(plan.dailyPlan || []).map((day) => (
            <div key={day.day} className="card day-plan-card">
              <div className="day-plan-head">
                <div className="day-plan-number">{day.day}</div>
                <div>
                  <h3 style={{ fontSize: '0.98rem' }}>Day {day.day}</h3>
                  {day.focus && <p style={{ fontSize: '0.84rem' }}>{day.focus}</p>}
                </div>
              </div>

              {(day.sessions || []).map((session, idx) => (
                <div key={idx} className="session-item">
                  <span style={{ fontWeight: 600 }}>{session.subject}</span>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--text-secondary)' }}>
                    <Clock size={13} /> {session.duration}
                  </span>
                  <span style={{ color: 'var(--text-secondary)', flexBasis: '100%' }}>
                    {session.activity}
                  </span>
                </div>
              ))}
            </div>
          ))}

          {plan.tips && plan.tips.length > 0 && (
            <div className="card" style={{ padding: 24, marginTop: 8 }}>
              <div className="panel-title">
                <Lightbulb size={18} color="var(--navy)" />
                Tips for success
              </div>
              <ul className="tips-list">
                {plan.tips.map((tip, idx) => (
                  <li key={idx}>
                    <Lightbulb size={14} color="var(--soft-pink)" style={{ marginTop: 3, flexShrink: 0 }} />
                    {tip}
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      )}
    </div>
  )
}

export default StudyPlan
