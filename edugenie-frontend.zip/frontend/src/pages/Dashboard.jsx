import { useNavigate } from 'react-router-dom'
import {
  Sparkles,
  MessageCircle,
  FileText,
  ListChecks,
  CalendarClock,
  Lightbulb,
  ArrowRight,
} from 'lucide-react'
import FeatureCard from '../components/FeatureCard.jsx'

const features = [
  {
    icon: MessageCircle,
    title: 'AI Tutor',
    description: 'Ask questions and get clear, step-by-step explanations from Gemini.',
    to: '/ai-tutor',
  },
  {
    icon: FileText,
    title: 'Smart Summarizer',
    description: 'Turn long notes or articles into short, medium, or detailed summaries.',
    to: '/summarizer',
  },
  {
    icon: ListChecks,
    title: 'Quiz Generator',
    description: 'Generate custom quizzes on any topic to test what you know.',
    to: '/quiz',
  },
  {
    icon: CalendarClock,
    title: 'Study Planner',
    description: 'Get a personalized day-by-day plan before your next exam.',
    to: '/study-plan',
  },
]

function Dashboard() {
  const navigate = useNavigate()

  return (
    <div>
      <section className="hero">
        <div className="hero-content">
          <span className="badge badge-lavender">
            <Sparkles size={13} /> AI-Powered Learning
          </span>
          <h1>Learn smarter with EduGenie</h1>
          <p>
            Your Gemini-powered study companion — get instant explanations, summarize dense
            material, practice with generated quizzes, and follow a study plan built around
            your schedule.
          </p>
          <div className="hero-actions">
            <button className="btn btn-accent" onClick={() => navigate('/ai-tutor')}>
              Start Learning <ArrowRight size={16} />
            </button>
            <div className="gemini-status">
              <span className="status-dot" />
              Gemini is online
            </div>
          </div>
        </div>
      </section>

      <h2 className="section-title">Explore your tools</h2>
      <div className="feature-grid">
        {features.map((f) => (
          <FeatureCard key={f.to} {...f} />
        ))}
      </div>

      <div className="card tip-card">
        <div className="tip-card-icon">
          <Lightbulb size={18} />
        </div>
        <div>
          <h3 style={{ marginBottom: 6, fontSize: '0.98rem' }}>Study tip of the day</h3>
          <p>
            Try the Feynman technique: explain a concept out loud in the simplest words you
            can, as if teaching a beginner. Gaps in your explanation point to gaps in your
            understanding — use the AI Tutor to fill them in.
          </p>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
