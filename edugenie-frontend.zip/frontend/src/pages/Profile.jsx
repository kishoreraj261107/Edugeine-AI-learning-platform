import { GraduationCap, BookOpen, ListChecks, MessageCircle } from 'lucide-react'

const stats = [
  { icon: BookOpen, label: 'Study Sessions', value: 24 },
  { icon: ListChecks, label: 'Quizzes Taken', value: 12 },
  { icon: MessageCircle, label: 'AI Questions Asked', value: 87 },
]

function Profile() {
  return (
    <div>
      <div className="page-header">
        <h1>Profile</h1>
        <p>Your EduGenie learning activity at a glance.</p>
      </div>

      <div className="card profile-header">
        <div className="profile-avatar">S</div>
        <div>
          <h2 style={{ fontSize: '1.3rem', marginBottom: 8 }}>Student Name</h2>
          <span className="badge badge-pink">
            <GraduationCap size={13} /> AI Learner
          </span>
        </div>
      </div>

      <h2 className="section-title">Your activity</h2>
      <div className="stats-grid">
        {stats.map(({ icon: Icon, label, value }) => (
          <div key={label} className="card stat-card">
            <div className="stat-icon">
              <Icon size={20} />
            </div>
            <div className="stat-value">{value}</div>
            <div className="stat-label">{label}</div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default Profile
