import ChatBox from '../components/ChatBox.jsx'

function AIChat() {
  return (
    <div className="chat-page">
      <div className="page-header">
        <h1>AI Tutor</h1>
        <p>Ask a question and get a clear, patient explanation — powered by Gemini.</p>
      </div>
      <ChatBox />
    </div>
  )
}

export default AIChat
