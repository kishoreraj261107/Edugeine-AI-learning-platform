import { useState } from 'react'
import {
  ListChecks,
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  RotateCcw,
  Trophy,
  Check,
  X,
} from 'lucide-react'
import QuizCard from '../components/QuizCard.jsx'
import Loading from '../components/Loading.jsx'
import { generateQuiz } from '../services/api.js'

const QUESTION_COUNTS = [5, 10, 15, 20]
const DIFFICULTIES = ['easy', 'medium', 'hard']

// Phases: 'setup' -> 'taking' -> 'results'
function Quiz() {
  const [phase, setPhase] = useState('setup')
  const [topic, setTopic] = useState('')
  const [numberOfQuestions, setNumberOfQuestions] = useState(5)
  const [difficulty, setDifficulty] = useState('medium')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  const [quiz, setQuiz] = useState(null)
  const [currentIndex, setCurrentIndex] = useState(0)
  const [answers, setAnswers] = useState({})
  const [submittedQuestions, setSubmittedQuestions] = useState({})

  async function handleGenerate(e) {
    e.preventDefault()
    if (!topic.trim()) {
      setError('Please enter a topic for the quiz.')
      return
    }
    setError('')
    setIsLoading(true)

    try {
      const result = await generateQuiz(topic.trim(), numberOfQuestions, difficulty)
      setQuiz(result)
      setAnswers({})
      setSubmittedQuestions({})
      setCurrentIndex(0)
      setPhase('taking')
    } catch (err) {
      setError(err.message)
    } finally {
      setIsLoading(false)
    }
  }

  function selectAnswer(index) {
    setAnswers((prev) => ({ ...prev, [currentIndex]: index }))
  }

  function submitCurrentAnswer() {
    setSubmittedQuestions((prev) => ({ ...prev, [currentIndex]: true }))
  }

  function goNext() {
    if (currentIndex < quiz.questions.length - 1) {
      setCurrentIndex((i) => i + 1)
    } else {
      setPhase('results')
    }
  }

  function goPrev() {
    if (currentIndex > 0) setCurrentIndex((i) => i - 1)
  }

  function startNewQuiz() {
    setPhase('setup')
    setQuiz(null)
    setTopic('')
    setAnswers({})
    setSubmittedQuestions({})
    setCurrentIndex(0)
  }

  function computeScore() {
    if (!quiz) return 0
    return quiz.questions.reduce((score, q, idx) => (answers[idx] === q.answer ? score + 1 : score), 0)
  }

  // ---------- SETUP PHASE ----------
  if (phase === 'setup') {
    return (
      <div>
        <div className="page-header">
          <h1>Quiz Generator</h1>
          <p>Pick a topic and EduGenie will build a custom quiz for you.</p>
        </div>

        {error && (
          <div className="error-banner">
            <AlertTriangle size={16} />
            {error}
          </div>
        )}

        <form className="card quiz-setup-card" onSubmit={handleGenerate}>
          <div className="field">
            <label htmlFor="topic">Topic</label>
            <input
              id="topic"
              type="text"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              placeholder="e.g. Cell Biology, World War II, Data Structures"
            />
          </div>

          <div className="field">
            <label>Number of questions</label>
            <div className="segmented">
              {QUESTION_COUNTS.map((n) => (
                <button
                  key={n}
                  type="button"
                  className={numberOfQuestions === n ? 'active' : ''}
                  onClick={() => setNumberOfQuestions(n)}
                >
                  {n}
                </button>
              ))}
            </div>
          </div>

          <div className="field">
            <label>Difficulty</label>
            <div className="segmented">
              {DIFFICULTIES.map((d) => (
                <button
                  key={d}
                  type="button"
                  className={difficulty === d ? 'active' : ''}
                  onClick={() => setDifficulty(d)}
                >
                  {d.charAt(0).toUpperCase() + d.slice(1)}
                </button>
              ))}
            </div>
          </div>

          <button className="btn btn-accent btn-block" type="submit" disabled={isLoading}>
            <ListChecks size={16} />
            {isLoading ? 'Generating quiz...' : 'Generate Quiz'}
          </button>

          {isLoading && <Loading label="Gemini is building your quiz..." />}
        </form>
      </div>
    )
  }

  // ---------- TAKING PHASE ----------
  if (phase === 'taking' && quiz) {
    const question = quiz.questions[currentIndex]
    const isSubmitted = !!submittedQuestions[currentIndex]
    const hasSelected = answers[currentIndex] !== undefined
    const isLast = currentIndex === quiz.questions.length - 1

    return (
      <div>
        <div className="page-header">
          <h1>{quiz.title || `Quiz: ${quiz.topic}`}</h1>
          <p>
            Topic: {quiz.topic} · Difficulty: {quiz.difficulty}
          </p>
        </div>

        <div className="quiz-progress">
          <span style={{ fontSize: '0.84rem', color: 'var(--text-secondary)', fontWeight: 600 }}>
            {currentIndex + 1} / {quiz.questions.length}
          </span>
          <div className="quiz-progress-bar">
            <div
              className="quiz-progress-fill"
              style={{ width: `${((currentIndex + 1) / quiz.questions.length) * 100}%` }}
            />
          </div>
        </div>

        <QuizCard
          question={question}
          selectedIndex={answers[currentIndex] ?? null}
          submitted={isSubmitted}
          onSelect={selectAnswer}
        />

        <div className="quiz-nav" style={{ marginTop: 20 }}>
          <button className="btn btn-outline" onClick={goPrev} disabled={currentIndex === 0}>
            <ArrowLeft size={16} /> Previous
          </button>

          {!isSubmitted ? (
            <button className="btn btn-primary" onClick={submitCurrentAnswer} disabled={!hasSelected}>
              Check Answer
            </button>
          ) : (
            <button className="btn btn-accent" onClick={goNext}>
              {isLast ? 'See Results' : 'Next'} <ArrowRight size={16} />
            </button>
          )}
        </div>
      </div>
    )
  }

  // ---------- RESULTS PHASE ----------
  if (phase === 'results' && quiz) {
    const score = computeScore()
    const total = quiz.questions.length
    const percent = Math.round((score / total) * 100)

    return (
      <div>
        <div className="card quiz-score-card">
          <Trophy size={36} color="var(--pink)" />
          <h2 style={{ marginTop: 14 }}>Quiz Complete</h2>
          <div className="quiz-score-value">
            {score}/{total}
          </div>
          <p>You scored {percent}% on "{quiz.topic}"</p>
          <button className="btn btn-accent" style={{ marginTop: 22 }} onClick={startNewQuiz}>
            <RotateCcw size={16} /> Create New Quiz
          </button>
        </div>

        <h2 className="section-title" style={{ marginTop: 32 }}>
          Review
        </h2>
        <div className="quiz-review-list">
          {quiz.questions.map((q, idx) => {
            const userAnswer = answers[idx]
            const isCorrect = userAnswer === q.answer
            return (
              <div key={idx} className="card quiz-review-item">
                <div className="quiz-review-item-head">
                  {isCorrect ? (
                    <Check size={16} color="#3FBF6F" />
                  ) : (
                    <X size={16} color="#E1544D" />
                  )}
                  Question {idx + 1}: {q.question}
                </div>
                <p style={{ marginBottom: 4 }}>
                  Your answer: {userAnswer !== undefined ? q.options[userAnswer] : 'Not answered'}
                </p>
                {!isCorrect && (
                  <p style={{ marginBottom: 4, color: 'var(--navy)' }}>
                    Correct answer: {q.options[q.answer]}
                  </p>
                )}
                {q.explanation && <p style={{ fontSize: '0.85rem' }}>{q.explanation}</p>}
              </div>
            )
          })}
        </div>
      </div>
    )
  }

  return null
}

export default Quiz
