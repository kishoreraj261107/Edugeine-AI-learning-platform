import { useState } from 'react'
import { FileText, AlignLeft, Copy, Check, AlertTriangle, Sparkles } from 'lucide-react'
import Loading from '../components/Loading.jsx'
import { summarizeText } from '../services/api.js'

const MAX_CHARS = 12000

const LENGTH_OPTIONS = [
  { value: 'short', label: 'Short' },
  { value: 'medium', label: 'Medium' },
  { value: 'detailed', label: 'Detailed' },
]

function Summarizer() {
  const [text, setText] = useState('')
  const [length, setLength] = useState('medium')
  const [summary, setSummary] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [copied, setCopied] = useState(false)

  async function handleGenerate() {
    if (!text.trim()) {
      setError('Paste or type some text to summarize first.')
      return
    }
    setError('')
    setIsLoading(true)
    setSummary('')

    try {
      const result = await summarizeText(text.trim(), length)
      setSummary(result)
    } catch (err) {
      setError(err.message)
    } finally {
      setIsLoading(false)
    }
  }

  async function handleCopy() {
    if (!summary) return
    try {
      await navigator.clipboard.writeText(summary)
      setCopied(true)
      setTimeout(() => setCopied(false), 1800)
    } catch {
      setError('Could not copy to clipboard.')
    }
  }

  return (
    <div>
      <div className="page-header">
        <h1>Smart Summarizer</h1>
        <p>Paste your notes, articles, or textbook excerpts and get a concise summary.</p>
      </div>

      {error && (
        <div className="error-banner">
          <AlertTriangle size={16} />
          {error}
        </div>
      )}

      <div className="summarizer-grid">
        <div className="card panel">
          <div className="panel-title">
            <FileText size={18} color="var(--navy)" />
            Your text
          </div>

          <div className="field">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value.slice(0, MAX_CHARS))}
              placeholder="Paste your text here..."
              style={{ minHeight: 220 }}
              aria-label="Text to summarize"
            />
          </div>
          <div className="char-counter">
            {text.length} / {MAX_CHARS} characters
          </div>

          <div className="field">
            <label>Summary length</label>
            <div className="segmented">
              {LENGTH_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  className={length === opt.value ? 'active' : ''}
                  onClick={() => setLength(opt.value)}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          <button className="btn btn-accent btn-block" onClick={handleGenerate} disabled={isLoading}>
            <Sparkles size={16} />
            {isLoading ? 'Generating...' : 'Generate Summary'}
          </button>
        </div>

        <div className="card panel">
          <div className="panel-title">
            <AlignLeft size={18} color="var(--navy)" />
            Summary
          </div>

          {isLoading && <Loading label="Summarizing your text..." size="panel" />}

          {!isLoading && summary && (
            <>
              <div className="summary-output">{summary}</div>
              <div className="panel-footer-actions">
                <button className="btn btn-outline btn-sm" onClick={handleCopy}>
                  {copied ? <Check size={14} /> : <Copy size={14} />}
                  {copied ? 'Copied' : 'Copy summary'}
                </button>
              </div>
            </>
          )}

          {!isLoading && !summary && (
            <div className="summary-output-empty">
              <AlignLeft size={26} color="var(--soft-pink)" />
              Your summary will appear here once generated.
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default Summarizer
